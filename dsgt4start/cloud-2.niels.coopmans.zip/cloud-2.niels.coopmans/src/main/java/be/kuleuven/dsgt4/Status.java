package be.kuleuven.dsgt4;

public enum Status {
    AVAILABLE, RESERVED, ORDERED
}
