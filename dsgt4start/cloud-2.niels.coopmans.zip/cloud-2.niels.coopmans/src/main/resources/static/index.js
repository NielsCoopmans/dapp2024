import { setupAuth, wireUpAuthChange,wireUpEvents } from './auth.js';

setupAuth();
wireUpAuthChange();
wireUpEvents();

