export const firebaseConfig = {
    // Development environment configuration
    development: {
        apiKey: "AIzaSyBoLKKR7OFL2ICE15Lc1-8czPtnbej0jWY",
        projectId: "demo-distributed-systems-kul",
    },
    // Production environment configuration
    production: {
        apiKey: "AIzaSyBtQOOAqO4bj_-nl3yZyQLWHmzxbjyZkZE",
        authDomain: "car-shop-426409.firebaseapp.com",
        projectId: "car-shop-426409",
        storageBucket: "car-shop-426409.appspot.com",
        messagingSenderId: "442266367149",
        appId: "1:442266367149:web:3ccef029cca87778acc224"
    }
};