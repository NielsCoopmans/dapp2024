package be.kuleuven.carrestservice.exceptions;

import java.util.UUID;

public class CarNotFoundException extends RuntimeException {

    public CarNotFoundException(UUID id) {
        super("Could not find car " + id);
    }
}
