package be.kuleuven.exhaustsystemrestservice.controllers;
import org.springframework.http.ResponseEntity;
import be.kuleuven.exhaustsystemrestservice.domain.ExhaustSystem;
import be.kuleuven.exhaustsystemrestservice.domain.ExhaustSystemRepository;
import be.kuleuven.exhaustsystemrestservice.exceptions.ExhaustSystemNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
public class ExhaustSystemRestController {
    private static final Logger logger = LoggerFactory.getLogger(ExhaustSystemRestController.class);
    private final ExhaustSystemRepository exhaustSystemRepository;

    @Autowired
    ExhaustSystemRestController(ExhaustSystemRepository exhaustSystemRepository) {
        this.exhaustSystemRepository = exhaustSystemRepository;
    }

    @GetMapping("/rest/exhaustsystems/{id}")
    public EntityModel<ExhaustSystem> getExhaustSystemById(@PathVariable int id) {
        logger.info("GET /rest/exhaustsystems/{}", id);
        ExhaustSystem exhaustSystem = exhaustSystemRepository.findExhaustSystem(id)
                .orElseThrow(() -> new ExhaustSystemNotFoundException(String.valueOf(id)));
        logger.info("Exhaust System ID {} found: {}", id, exhaustSystem);

        return exhaustSystemToEntityModel(id, exhaustSystem);
    }

    @GetMapping("/rest/exhaustsystems")
    public CollectionModel<EntityModel<ExhaustSystem>> getExhaustSystems() {
        logger.info("GET /rest/exhaustsystems");
        Collection<ExhaustSystem> exhaustSystems = exhaustSystemRepository.getAllExhaustSystems();
        logger.info("Found {} exhaust systems", exhaustSystems.size());

        List<EntityModel<ExhaustSystem>> exhaustSystemEntityModels = exhaustSystems.stream()
                .map(es -> exhaustSystemToEntityModel(es.getId(), es))
                .collect(Collectors.toList());

        logger.info("Returning exhaust system collection model");

        return CollectionModel.of(exhaustSystemEntityModels,
                linkTo(methodOn(ExhaustSystemRestController.class).getExhaustSystems()).withSelfRel());
    }


    @PostMapping("/rest/exhaustsystems/order/{id}")
    public ResponseEntity<String> orderExhaustSystem(@PathVariable int id) {
        logger.info("POST /rest/exhaustsystems/order/{}", id);
        boolean success = exhaustSystemRepository.orderExhaustSystem(id);
        String message;
        ResponseEntity<String> response;

        if (success) {
            message = "Order placed successfully for Exhaust System ID: " + id;
            logger.info(message);
            response = ResponseEntity.ok(message); // 200 OK
        } else {
            ExhaustSystem exhaustSystem = exhaustSystemRepository.findExhaustSystem(id).orElse(null);
            if (exhaustSystem == null) {
                message = "Order failed: Exhaust System ID " + id + " not found.";
                logger.warn(message);
                response = ResponseEntity.status(404).body(message); // 404 Not Found
            } else if (exhaustSystem.getStock() <= 0) {
                message = "Order failed: Exhaust System ID " + id + " is out of stock.";
                logger.warn(message);
                response = ResponseEntity.status(409).body(message); // 409 Conflict
            } else {
                message = "Order failed for unknown reasons.";
                logger.warn(message);
                response = ResponseEntity.status(500).body(message); // 500 Internal Server Error
            }
        }

        return response;
    }


    @PostMapping("/rest/exhaustsystems/cancel/{id}")
    public ResponseEntity<String> cancelOrder(@PathVariable int id) {
        logger.info("POST /rest/exhaustsystems/cancel/{}", id);
        boolean success = exhaustSystemRepository.cancelOrder(id);
        String message;

        if (success) {
            message = "Order cancelled successfully for Exhaust System ID: " + id;
            logger.info(message);
        } else {
            message = "Cancel order failed: Exhaust System ID " + id + " not found.";
            logger.warn(message);
        }

        return ResponseEntity.ok(message);
    }

    private EntityModel<ExhaustSystem> exhaustSystemToEntityModel(int id, ExhaustSystem exhaustSystem) {
        logger.info("Generating EntityModel for Exhaust System ID: {}", id);
        return EntityModel.of(exhaustSystem,
                linkTo(methodOn(ExhaustSystemRestController.class).getExhaustSystemById(id)).withSelfRel(),
                linkTo(methodOn(ExhaustSystemRestController.class).getExhaustSystems()).withRel("rest/exhaustsystems"));
    }
}
