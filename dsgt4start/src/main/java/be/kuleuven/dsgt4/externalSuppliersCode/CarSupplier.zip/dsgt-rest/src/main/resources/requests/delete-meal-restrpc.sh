curl -X POST localhost:8089/api/cars/ed25760f-e77a-49fe-9037-0f41bca37acd/reserve

