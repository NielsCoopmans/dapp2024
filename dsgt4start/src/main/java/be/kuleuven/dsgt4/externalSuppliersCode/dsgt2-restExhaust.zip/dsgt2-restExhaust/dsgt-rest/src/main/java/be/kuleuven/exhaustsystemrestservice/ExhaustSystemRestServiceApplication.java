package be.kuleuven.exhaustsystemrestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExhaustSystemRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExhaustSystemRestServiceApplication.class, args);
	}
}
