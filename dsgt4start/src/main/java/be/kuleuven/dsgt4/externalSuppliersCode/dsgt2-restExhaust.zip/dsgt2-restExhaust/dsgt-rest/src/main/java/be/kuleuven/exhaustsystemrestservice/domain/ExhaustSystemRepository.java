package be.kuleuven.exhaustsystemrestservice.domain;

import net.minidev.json.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
public class ExhaustSystemRepository {
    // map: id -> exhaust system
    private static final Map<Integer, ExhaustSystem> exhaustSystems = new HashMap<>();
    private static int currentId = 1;  // to generate unique IDs

    @PostConstruct
    public void initData() {
        ExhaustSystem a = new ExhaustSystem();
        a.setId(currentId++);
        a.setName("Simoni Racing ESR086/B");
        a.setBrand("Simoni Racing");
        a.setPrice(78.24);
        a.setStock(10);  // Example stock quantity

        exhaustSystems.put(a.getId(), a);

        ExhaustSystem b = new ExhaustSystem();
        b.setId(currentId++);
        b.setName("Akrapovic Racing Line, S-B10R5-HAPLT");
        b.setBrand("Akrapovic");
        b.setPrice(2182.22);
        b.setStock(5);  // Example stock quantity

        exhaustSystems.put(b.getId(), b);

        ExhaustSystem c = new ExhaustSystem();
        c.setId(currentId++);
        c.setName("Novus Group N A2752ED76");
        c.setBrand("Novus");
        c.setPrice(159.75);
        c.setStock(8);  // Example stock quantity

        exhaustSystems.put(c.getId(), c);

        ExhaustSystem d = new ExhaustSystem();
        d.setId(currentId++);
        d.setName("Remus RACING GPF-Back");
        d.setBrand("Remus");
        d.setPrice(1338.26);
        d.setStock(6);  // Example stock quantity

        exhaustSystems.put(d.getId(), d);

        ExhaustSystem e = new ExhaustSystem();
        e.setId(currentId++);
        e.setName("Akrapovič Evolution Line");
        e.setBrand("Akrapovič");
        e.setPrice(8107.29);
        e.setStock(2);  // Example stock quantity

        exhaustSystems.put(e.getId(), e);

        ExhaustSystem f = new ExhaustSystem();
        f.setId(currentId++);
        f.setName("Electric Exhaust Valve, 2.5in");
        f.setBrand("Unknown");
        f.setPrice(145.99);
        f.setStock(12);  // Example stock quantity

        exhaustSystems.put(f.getId(), f);

        ExhaustSystem g = new ExhaustSystem();
        g.setId(currentId++);
        g.setName("Scorpion 2.5/63.5mm");
        g.setBrand("Scorpion");
        g.setPrice(855.00);
        g.setStock(4);  // Example stock quantity

        exhaustSystems.put(g.getId(), g);

        ExhaustSystem h = new ExhaustSystem();
        h.setId(currentId++);
        h.setName("63MM (2.5\") Exhaust Tips");
        h.setBrand("Unknown");
        h.setPrice(53.63);
        h.setStock(20);  // Example stock quantity

        exhaustSystems.put(h.getId(), h);
    }

    public void addExhaustSystem(JSONObject newExhaustSystemJSON) {
        ExhaustSystem newExhaustSystem = new ExhaustSystem();
        newExhaustSystem.setId(currentId++);
        newExhaustSystem.setName(newExhaustSystemJSON.get("name").toString());
        newExhaustSystem.setBrand(newExhaustSystemJSON.get("brand").toString());
        newExhaustSystem.setPrice(Double.valueOf(newExhaustSystemJSON.get("price").toString()));
        newExhaustSystem.setStock(Integer.parseInt(newExhaustSystemJSON.get("stock").toString()));  // Set stock from JSON
        exhaustSystems.put(newExhaustSystem.getId(), newExhaustSystem);
    }

    public Optional<ExhaustSystem> findExhaustSystem(int id) {
        ExhaustSystem exhaustSystem = exhaustSystems.get(id);
        return Optional.ofNullable(exhaustSystem);
    }

    public Collection<ExhaustSystem> getAllExhaustSystems() {
        return exhaustSystems.values();
    }

    public ExhaustSystem getCheapestExhaustSystem() {
        return exhaustSystems.values().stream()
                .min(Comparator.comparing(ExhaustSystem::getPrice))
                .orElse(null);
    }

    public boolean orderExhaustSystem(int id) {
        ExhaustSystem exhaustSystem = exhaustSystems.get(id);
        if (exhaustSystem != null && exhaustSystem.getStock() > 0) {
            exhaustSystem.setStock(exhaustSystem.getStock() - 1);
            return true;
        } else {
            return false;
        }
    }

    public boolean cancelOrder(int id) {
        ExhaustSystem exhaustSystem = exhaustSystems.get(id);
        if (exhaustSystem != null) {
            exhaustSystem.setStock(exhaustSystem.getStock() + 1);
            return true;
        } else {
            return false;
        }
    }
}
