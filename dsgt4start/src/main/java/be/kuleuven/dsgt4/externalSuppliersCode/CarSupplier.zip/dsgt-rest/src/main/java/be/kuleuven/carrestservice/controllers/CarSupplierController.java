package be.kuleuven.carrestservice.controllers;

import be.kuleuven.carrestservice.domain.Car;
import be.kuleuven.carrestservice.domain.CarService;
import be.kuleuven.carrestservice.domain.StatusResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/cars")
public class CarSupplierController {
    @Autowired
    private CarService carService;

    private static final String API_KEY = "Iw8zeveVyaPNWonPNaU0213uw3g6Ei";

    @GetMapping
    public CollectionModel<EntityModel<Car>> getAllCars(@RequestParam String key) {
        List<EntityModel<Car>> cars = carService.getAllCars().stream()
                .map(car -> EntityModel.of(car,
                        linkTo(methodOn(CarSupplierController.class).getCarById(car.getId(), key)).withSelfRel(),
                        linkTo(methodOn(CarSupplierController.class).getAllCars(key)).withRel("cars")))
                .toList();
        return CollectionModel.of(cars, linkTo(methodOn(CarSupplierController.class).getAllCars(key)).withSelfRel());
    }

    @GetMapping("/{id}")
    public EntityModel<Car> getCarById(@PathVariable UUID id, @RequestParam String key) {
        Car car = carService.getCarById(id);
        if (car == null) {
            return EntityModel.of(null, linkTo(methodOn(CarSupplierController.class).getAllCars(key)).withRel("cars"));
        }
        return EntityModel.of(car,
                linkTo(methodOn(CarSupplierController.class).getCarById(id, key)).withSelfRel(),
                linkTo(methodOn(CarSupplierController.class).getAllCars(key)).withRel("cars"));
    }

    @PostMapping("/{id}/order")
    public ResponseEntity<String> orderCar(@PathVariable UUID id) {
        boolean succes = carService.orderCar(id);
        String message = succes ? "Car ordered succesfully" : "Car not available or not found";
        HttpStatus status = succes ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return new ResponseEntity<>(message, status);
    }

    @PostMapping("/{id}/reserve")
    public ResponseEntity<String> reserveCar(@PathVariable UUID id) {
        boolean succes = carService.reserveCar(id);
        String message = succes ? "Car reserved succesfully" : "Car not available or not found";
        HttpStatus status = succes ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return new ResponseEntity<>(message, status);
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable UUID id) {
        boolean response = carService.cancelOrder(id);
        String message = response ? "Order cancelled" : "Car not found or not ordered";
        HttpStatus status = response ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return new ResponseEntity<>(message, status);
    }
}
