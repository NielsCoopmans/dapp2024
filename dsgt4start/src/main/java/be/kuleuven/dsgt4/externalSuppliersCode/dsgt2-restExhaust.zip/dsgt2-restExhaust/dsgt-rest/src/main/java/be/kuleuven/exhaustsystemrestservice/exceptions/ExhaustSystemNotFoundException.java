package be.kuleuven.exhaustsystemrestservice.exceptions;

public class ExhaustSystemNotFoundException extends RuntimeException {

    public ExhaustSystemNotFoundException(String id) {
        super("Could not find exhaust system " + id);
    }
}
