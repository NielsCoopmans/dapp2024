package be.kuleuven.carrestservice.domain;

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class CarService {
    private static final List<Car> cars = new ArrayList<>();

    @PostConstruct
    public void initData() {
        cars.add(new Car(UUID.randomUUID(),"Audi", "A4", "Black", 2019, 30000, "Audi A4 Black 2019"));
        cars.add(new Car(UUID.randomUUID(),"BMW", "X5", "White", 2020, 50000, "BMW X5 White 2020"));
        cars.add(new Car(UUID.randomUUID(),"Mercedes", "C-Class", "Silver", 2018, 35000, "Mercedes C-Class Silver 2018"));
        cars.add(new Car(UUID.randomUUID(),"Volkswagen", "Golf", "Blue", 2017, 20000, "Volkswagen Golf Blue 2017"));
        cars.add(new Car(UUID.randomUUID(),"Toyota", "Corolla", "Red", 2016, 15000, "Toyota Corolla Red 2016"));
        cars.add(new Car(UUID.randomUUID(),"Ford", "Focus", "Green", 2015, 10000, "Ford Focus Green 2015"));
    }

    public List<Car> getAllCars() {
        return cars;
    }

    public Car getCarById(UUID id) {
        return cars.stream().filter(car -> car.getId().equals(id)).findFirst().orElse(null);
    }

    public boolean orderCar(UUID id) {
        Car car = getCarById(id);
        //Order car when it is reserved
        if(car == null || car.getStatus() == Car.Status.ORDERED){
            return false;
        }
        car.setStatus(Car.Status.ORDERED);
        return true;
    }

    public boolean reserveCar(UUID id) {
        Car car = getCarById(id);
        if(car == null || car.getStatus() != Car.Status.AVAILABLE){
            return false;
        }
        car.setStatus(Car.Status.RESERVED);
        return true;
    }

    public boolean cancelOrder(UUID id) {
        Car car = getCarById(id);
        if(car == null || car.getStatus() == Car.Status.AVAILABLE){
            return false;
        }
        car.setStatus(Car.Status.AVAILABLE);
        return true;
    }
}
