package be.kuleuven.exhaustsystemrestservice.controllers;

import be.kuleuven.exhaustsystemrestservice.domain.ExhaustSystem;
import be.kuleuven.exhaustsystemrestservice.domain.ExhaustSystemRepository;
import be.kuleuven.exhaustsystemrestservice.exceptions.ExhaustSystemNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.Collection;
import java.util.Optional;

@RestController
@RequestMapping("/restrpc/exhaustsystems")
public class ExhaustSystemRestRpcStyleController {

    private static final Logger logger = LoggerFactory.getLogger(ExhaustSystemRestRpcStyleController.class);
    private final ExhaustSystemRepository exhaustSystemRepository;

    @Autowired
    public ExhaustSystemRestRpcStyleController(ExhaustSystemRepository exhaustSystemRepository) {
        this.exhaustSystemRepository = exhaustSystemRepository;
    }

    @PostConstruct
    public void init() {
        logger.info("ExhaustSystemRestRpcStyleController initialized");
    }

    @GetMapping("/{id}")
    public ExhaustSystem getExhaustSystemById(@PathVariable int id) {  // Changed parameter type to int
        logger.info("GET /restrpc/exhaustsystems/{}", id);
        Optional<ExhaustSystem> exhaustSystem = exhaustSystemRepository.findExhaustSystem(id);
        return exhaustSystem.orElseThrow(() -> new ExhaustSystemNotFoundException(String.valueOf(id)));
    }

    @GetMapping
    public Collection<ExhaustSystem> getExhaustSystems() {
        logger.info("GET /restrpc/exhaustsystems");
        return exhaustSystemRepository.getAllExhaustSystems();
    }

    @PostMapping("/order/{id}")
    public boolean orderExhaustSystem(@PathVariable int id) {  // New method for ordering an exhaust system
        logger.info("POST /rest/exhaustsystems/order/{}", id);
        boolean success = exhaustSystemRepository.orderExhaustSystem(id);
        if (success) {
            logger.info("Order placed successfully for Exhaust System ID: {}", id);
        } else {
            ExhaustSystem exhaustSystem = exhaustSystemRepository.findExhaustSystem(id).orElse(null);
            if (exhaustSystem == null) {
                logger.warn("Order failed: Exhaust System ID {} not found", id);
            } else if (exhaustSystem.getStock() <= 0) {
                logger.warn("Order failed: Exhaust System ID {} is out of stock", id);
            }
        }
        return success;
    }
}
